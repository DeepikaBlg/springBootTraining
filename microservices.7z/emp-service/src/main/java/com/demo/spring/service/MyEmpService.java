package com.demo.spring.service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpRequest;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

//import com.demo.springJdbc.EmployyeService;

@RestController
@RequestMapping("/emp")
public class MyEmpService {
	
	//@Autowired
	//EmployyeService employyeService;
	
	static Map<Integer, Employee> emps = new HashMap();
	static{
		emps.put(100, new Employee("Krithika Gupta", 111, 60000, "Bhopal"));
		emps.put(101, new Employee("Ranbir Kapoor", 112, 50000, "Nepal"));
		emps.put(102, new Employee("Abhishek Khurana", 113, 60000, "Imphal"));
		emps.put(103, new Employee("Rana Singh", 109, 670000, "Manipal"));
		emps.put(104, new Employee("Pratap Varma", 115, 69000, "Sikkim"));
	}

	@RequestMapping(path="/info", method=RequestMethod.GET)
	public String empMethod(){
		return "Spring Boot Info";
	}
	
	@RequestMapping(path="/find/{id}", method=RequestMethod.GET, produces={MediaType.APPLICATION_XML_VALUE, MediaType.APPLICATION_JSON_VALUE})
	public ResponseEntity getById(@PathVariable("id") int empId){
		if(emps.containsKey(empId)){
			return ResponseEntity.ok(emps.get(empId));
		}else{
			return ResponseEntity.ok("Employee not found!");
		}
	}
	
	/*@RequestMapping(path="/save", method=RequestMethod.POST, consumes=MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity saveEmp(HttpServletRequest req){
		if(req != null){
			
			com.demo.springJdbc.Employee e = (com.demo.springJdbc.Employee) req;
			employyeService.saveEmployee(e);
			return ResponseEntity.ok("Employee Saved!");
		}
		
		return ResponseEntity.ok("Error saving Employee!");
	}*/
}
