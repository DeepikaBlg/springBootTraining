package com.demo.spring;

import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
public class Employee {
	
	
	private String name;
	
	
	private int id;
	
	
	private double salary;
	
	
	private String location;
	
	public Employee() {
		
	}
	
	public Employee(String name, int id, double salary, String loc) {
		this.id = id;
		this.name = name;
		this.salary = salary;
		this.location = loc;
	}
	
	public String getName() {
		return name;
	}
	public int getId() {
		return id;
	}
	public double getSalary() {
		return salary;
	}
	public String getLocation() {
		return location;
	}

	public void setName(String name) {
		this.name = name;
	}

	public void setId(int id) {
		this.id = id;
	}

	public void setSalary(double salary) {
		this.salary = salary;
	}

	public void setLocation(String location) {
		this.location = location;
	}
	
	@Override
	public String toString(){
		return this.id+" "+this.name+" "+this.location+" "+this.salary;
		
	}
	
	
}
